import React from "react";

const Footer = () => {
  let foo = {
    color: "#fff",
    backgroundColor: "#000",
    padding: "20px 0px",
    marginTop: "80px",
  };
  return (
    <>
      <p style={foo}>COPYRIGHT(C) 2022 Nike, Inc. All Rights Reserved</p>
    </>
  );
};

export default Footer;
